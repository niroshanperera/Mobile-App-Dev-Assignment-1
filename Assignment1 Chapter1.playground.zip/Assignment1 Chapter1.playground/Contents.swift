//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"
str != "!"
print(str)



//Bronze Challenge
import Cocoa
let myName:String =  "Perera"
print(str)


